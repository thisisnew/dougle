import hashlib
import json
import re

from .handoff import failure_request
from .images import IMAGE_ERRORS
from .presentation import chat_text
from .progress import progress_text
from .safety import BotError, check_content, escape_slack

RESEARCH_ERRORS = {
    "unsafe_lookup_sql": "제안된 조회문을 검증하지 못했습니다. DB 접근 권한 오류로 확인된 것은 아닙니다.",
    "repair_changed_evidence": "표현을 다듬는 과정에서 검증한 근거 정보가 달라졌습니다. 이 답변은 게시할 수 없습니다.",
    "invalid_verification": "AI가 반환한 근거 확인 기록의 형식이 올바르지 않습니다. 권한 오류로 확인된 것은 아니며 이 답변은 게시할 수 없습니다.",
    "verification_requirements_missing": "질문에 필요한 확인 항목이 답변 기록에서 누락되었습니다. 이 답변은 게시할 수 없습니다.",
    "required_read_not_verified": "답변이 인용한 코드·자료 조회를 이번 실행의 성공 기록과 연결하지 못했습니다. 실제 조회 누락 또는 기록 불일치일 수 있으며 이 답변은 게시할 수 없습니다.",
    "invalid_read_trace": "자료 조회 실행 기록이 중복되거나 잘못되어 근거를 검증하지 못했습니다. 이 답변은 게시할 수 없습니다.",
    "engine_timeout": "설정된 처리 시간을 초과해 답변 생성을 중단했습니다. 자동으로 다시 실행하지 않았으며 채널에 답변을 게시하지 않았습니다.",
}

LABELS = {
    "queued": "처리 대기",
    "drafting": "답변 작성 중",
    "awaiting_approval": "게시 승인 대기",
    "needs_lookup": "개발자 확인 요청",
    "posting": "게시 중",
    "posted": "게시 완료",
    "rejected": "거절됨",
    "cancelled": "중단됨",
    "failed": "개발자 확인 요청",
    "post_unknown": "전송 여부 확인 필요",
}


def final_text(draft):
    body = draft["body"]
    sources = json.loads(draft["sources_json"])
    check_content(body, personal=True)
    text = chat_text(body, len(sources))
    if not text:
        raise BotError("empty_public_answer")
    return text


def preview_receipt(draft):
    return json.dumps(
        {"draft_id": draft["id"], "sha256": hashlib.sha256(final_text(draft).encode()).hexdigest()},
        sort_keys=True,
    )


def split_text(text, limit=3500):
    if len(text) <= limit:
        return [text]
    result = []
    current = ""
    fence = None
    for line in text.splitlines(keepends=True):
        if len(line) > limit - 40:
            raise BotError("answer_line_too_long")
        if len(current) + len(line) > limit - 40:
            result.append(current.rstrip() + ("\n```" if fence else ""))
            current = fence + "\n" if fence else ""
        current += line
        if line.lstrip().startswith("```"):
            fence = None if fence else line.strip()
    if current.strip():
        result.append(current.rstrip() + ("\n```" if fence else ""))
    if any(len(p) > limit for p in result):
        raise BotError("answer_too_long")
    return result


def section(text, block_id=None):
    result = {"type": "section", "text": {"type": "mrkdwn", "text": text or "내용이 없습니다."}}
    if block_id:
        result["block_id"] = block_id
    return result


def render(inquiry, draft, permalink=None):
    status = inquiry["status"]
    label = "개발자 직접 응대" if inquiry.get("human_takeover") else LABELS[status]
    blocks = [
        {"type": "header", "text": {"type": "plain_text", "text": label}},
        {"type": "context", "elements": [{"type": "plain_text", "text": f"문의 #{inquiry['id']}"}]},
        section("*질문*"),
        {
            "type": "section",
            "text": {
                "type": "plain_text",
                "text": inquiry["question_text"][:1000].replace("```", "\n").strip()
                or "질문 내용이 없습니다.",
            },
        },
        {"type": "divider"},
    ]
    if inquiry.get("error"):
        blocks.append(
            section(
                (IMAGE_ERRORS | RESEARCH_ERRORS).get(
                    inquiry["error"], "확인이 필요합니다: `" + inquiry["error"] + "`"
                )
            )
        )
    if status == "failed":
        blocks.append(section("*필요한 확인*\n" + failure_request(inquiry.get("error") or "")))
        blocks.append(
            section(
                "처리 결과를 입력하면 같은 문의의 답변을 이어서 준비합니다. 고객 채널에는 오류나 내부 요청을 게시하지 않습니다."
            )
        )
        if inquiry.get("job_id"):
            blocks.append(
                {
                    "type": "actions",
                    "elements": [
                        {
                            "type": "button",
                            "text": {"type": "plain_text", "text": "처리 결과 입력"},
                            "action_id": "assist",
                            "value": json.dumps(
                                {"inquiry_id": inquiry["id"], "job_id": inquiry["job_id"]}
                            ),
                        },
                        {
                            "type": "button",
                            "text": {"type": "plain_text", "text": "직접 응대할게요"},
                            "action_id": "take_over",
                            "value": json.dumps(
                                {"inquiry_id": inquiry["id"], "job_id": inquiry["job_id"]}
                            ),
                        },
                    ],
                }
            )
    if status in ("queued", "drafting"):
        blocks.append(
            section(
                "접수했습니다. 앞선 문의가 끝나면 답변을 준비하겠습니다."
                if status == "queued"
                else progress_text(inquiry["progress"])
                if inquiry.get("progress")
                else "답변을 준비하고 있습니다. 완료되면 이 카드에 답변과 게시 버튼이 표시됩니다."
            )
        )
        blocks.append(
            section("약 30초마다 갱신합니다. 아래 ‘중단’으로 이 문의만 멈출 수 있습니다.")
        )
    if status in ("queued", "drafting") and inquiry.get("job_id"):
        blocks.append(
            {
                "type": "actions",
                "elements": [
                    {
                        "type": "button",
                        "text": {"type": "plain_text", "text": "중단"},
                        "action_id": "cancel",
                        "value": json.dumps(
                            {"inquiry_id": inquiry["id"], "job_id": inquiry["job_id"]}
                        ),
                    }
                ],
            }
        )
    if status == "cancelled":
        blocks.append(
            section(
                "개발자께서 직접 응대하십니다. 더글은 이 문의에 자동 답변을 이어서 게시하지 않습니다."
                if inquiry.get("human_takeover")
                else "이 문의의 처리를 중단했습니다. 실행 중인 AI에는 종료를 요청하며, 늦게 도착하는 답변은 게시하지 않습니다. 다른 문의는 계속 처리합니다."
            )
        )
    if draft and status not in ("queued", "drafting", "cancelled", "failed"):
        if status == "needs_lookup":
            lookup = json.loads(draft["lookup_json"])
            blocks.append(section("*확인 대상*\n" + escape_slack(lookup["target"])))
            # Preserve the whole request, but separate its short paragraphs on mobile.
            # Older free-form requests are also readable; no semantic rewrite in this renderer.
            reason = lookup["reason"]
            for label in ("막힌 이유", "확인할 내용", "필요한 결과"):
                reason = re.sub(rf"(?m)^\s*{label}\s*[:：]\s*", f"*{label}*\n", reason)
            for paragraph in re.split(r"\n\s*\n", escape_slack(reason), maxsplit=2):
                for offset in range(0, len(paragraph), 2800):
                    blocks.append(section(paragraph[offset : offset + 2800]))
            if inquiry.get("sql_withheld") and not lookup["sql"]:
                blocks.append(
                    section(
                        "조회문은 안전성·스키마 검증을 통과하지 못해 제외했습니다. 확인 대상의 스키마부터 점검해 주세요."
                    )
                )
            if lookup["sql"]:
                sql = escape_slack(lookup["sql"])
                if len(sql) <= 2700:
                    blocks.append(section("*읽기 전용 조회문*\n```\n" + sql + "\n```"))
                else:
                    # Never show a truncated query whose filters/LIMIT might be missing.
                    blocks.append(
                        section(
                            "조회문이 길어 카드에 표시하지 않았습니다. 위 확인 대상과 조건에 맞는 최소 결과만 알려 주세요."
                        )
                    )
            display = "아래 버튼으로 필요한 결과만 요약해 주세요. 입력하시면 같은 문의의 답변을 이어서 준비합니다."
        else:
            display = final_text(draft)
            blocks.append(section("*답변*"))
        for idx in range(0, len(display), 2800):
            blocks.append(section(display[idx : idx + 2800], f"d{draft['id']}-{idx}"))
        answer_end = len(blocks)
        sources = json.loads(draft["sources_json"])
        if sources:
            blocks.append({"type": "divider"})
            blocks.append(
                {
                    "type": "context",
                    "elements": [
                        {"type": "plain_text", "text": "확인한 자료 · 승인자에게만 표시됩니다"}
                    ],
                }
            )
            source_block = ""
            for idx, source in enumerate(sources, 1):
                title = re.sub(r"^(?:\s*\[(?:R)?\d+\]\s*)+", "", source["title"])
                line = escape_slack(f"[{idx}] {title} · {source['location']}")
                # Escaped URLs can grow; split safely within Slack's per-section limit.
                for offset in range(0, len(line), 2700):
                    piece = line[offset : offset + 2700]
                    if len(source_block) + len(piece) + 2 > 2800:
                        blocks.append(section(source_block))
                        source_block = ""
                    source_block += ("\n\n" if source_block else "") + piece
            if source_block:
                blocks.append(section(source_block))
        value = json.dumps(
            {"inquiry_id": inquiry["id"], "draft_id": draft["id"]}, separators=(",", ":")
        )
        actions = []

        def button(action, label):
            actions.append(
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": label},
                    "action_id": action,
                    "value": value,
                }
            )

        if status == "awaiting_approval":
            button("post", "게시")
            actions[-1]["style"] = "primary"
            if len(draft["body"]) <= 3000:
                button("edit", "직접 수정")
        if status in ("awaiting_approval", "needs_lookup"):
            if status == "needs_lookup":
                button("lookup", "확인 결과 입력")
                button("take_over", "직접 응대할게요")
            else:
                button("reject", "거절")
        if status == "failed":
            button("reject", "거절")
        if actions:
            blocks.insert(answer_end, {"type": "actions", "elements": actions})
    if permalink:
        blocks.append(section("게시된 답변: " + permalink))
    if len(blocks) > 45:
        raise BotError("card_too_large")
    return "dougle · " + label + " · " + escape_slack(
        inquiry["question_text"][:100]
    ), blocks


def modal(action, inquiry, draft):
    if action not in ("edit", "lookup", "assist"):
        raise BotError("action_unavailable")
    labels = {
        "edit": "직접 수정",
        "lookup": "확인 결과 입력",
        "assist": "처리 결과 입력",
    }
    block = {
        "type": "input",
        "block_id": "content",
        "label": {"type": "plain_text", "text": labels[action]},
        "optional": False,
        "element": {
            "type": "plain_text_input",
            "action_id": "value",
            "multiline": True,
            "max_length": 3000,
        },
    }
    if action == "edit":
        if len(draft["body"]) > 3000:
            raise BotError("edit_too_long")
        block["element"]["initial_value"] = draft["body"]
    blocks = [block]
    if action in ("lookup", "assist"):
        block["hint"] = {
            "type": "plain_text",
            "text": "확인 대상·범위와 결과 또는 해결한 내용을 요약해 주세요. 토큰·개인정보·원본 데이터는 입력하지 마세요.",
        }
    return {
        "type": "modal",
        "callback_id": "dougle_" + action,
        "private_metadata": json.dumps(
            {
                "inquiry_id": inquiry["id"],
                **(
                    {"job_id": inquiry["job_id"]}
                    if action == "assist"
                    else {"draft_id": draft["id"]}
                ),
                "channel": inquiry["card_channel_id"],
                "ts": inquiry["card_ts"],
            }
        ),
        "title": {"type": "plain_text", "text": labels[action]},
        "submit": {"type": "plain_text", "text": "확인"},
        "close": {"type": "plain_text", "text": "취소"},
        "blocks": blocks,
    }
