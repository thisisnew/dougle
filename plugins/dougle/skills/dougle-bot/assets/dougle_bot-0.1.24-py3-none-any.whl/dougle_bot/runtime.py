import fcntl
import logging
import os
import platform
import signal
import subprocess
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .actions import Actions
from .config import private_dir
from .engine import ClaudeCliEngine
from .intake import receive
from .safety import BotError
from .slack_gateway import BoltSlackGateway
from .startup import check_engine, report
from .store import Store
from .worker import Worker


def process_inquiries(worker, store, stop):
    """Run one inquiry lane; shared Worker retains its card and Monitor locks."""
    try:
        while not stop.is_set() and store.control()["desired"] == "running":
            with store.processing():
                try:
                    worked = worker.run_once()
                except Exception:
                    # Stop peers before releasing an unexpectedly interrupted job.
                    stop.set()
                    store.stop("worker_failed")
                    return
            if not worked:
                stop.wait(0.25)
    except Exception:
        stop.set()
        store.stop("worker_failed")


def apple_silicon():
    if platform.system() != "Darwin":
        return False
    if platform.machine() == "arm64":
        return True
    try:
        result = subprocess.run(
            ["/usr/sbin/sysctl", "-n", "hw.optional.arm64"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=3,
        )
        return result.returncode == 0 and result.stdout.strip() == b"1"
    except (OSError, subprocess.SubprocessError):
        return False


class InstanceLock:
    def __init__(self, path):
        self.path = path
        self.file = None

    def __enter__(self):
        private_dir(self.path.parent)
        if self.path.is_symlink():
            raise BotError("unsafe_lock_path")
        self.file = self.path.open("a+")
        os.chmod(self.path, 0o600)
        try:
            fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            self.file.close()
            self.file = None
            raise BotError("already_running") from None
        return self

    def __exit__(self, *args):
        if self.file:
            fcntl.flock(self.file.fileno(), fcntl.LOCK_UN)
            self.file.close()


def running(home):
    path = Path(home) / "runtime.lock"
    if not path.exists():
        return False
    try:
        with path.open("a+") as f:
            try:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                return False
            except BlockingIOError:
                return True
    except OSError:
        raise BotError("status_unavailable") from None


def build_app(gateway, token, identity, store, config, worker, actions, executor):
    from slack_bolt import App
    from slack_bolt.authorization import AuthorizeResult

    logger = logging.getLogger("dougle_bot.slack")
    logger.handlers = [logging.NullHandler()]
    logger.propagate = False
    logger.setLevel(logging.CRITICAL)

    def authorize(**kwargs):
        return AuthorizeResult(
            enterprise_id=None,
            team_id=identity["team_id"],
            bot_token=token,
            bot_user_id=identity["user_id"],
            bot_id=identity.get("bot_id"),
        )

    app = App(
        client=gateway.client,
        authorize=authorize,
        process_before_response=True,
        request_verification_enabled=False,
        logger=logger,
    )

    def safe(fn, *args):
        try:
            fn(*args)
        except BotError:
            pass
        except Exception:
            store.audit(None, "system", "interaction_failed")

    @app.event("app_mention")
    def mention(ack, body):
        # process_before_response=True: local durable intake precedes Socket Mode ack.
        ident = receive(store, config, body, identity["user_id"])
        ack()
        if ident:
            executor.submit(safe, worker.notify, ident)

    def button(ack, body):
        user = body.get("user", {}).get("id")
        channel = body.get("channel", {}).get("id")
        ts = body.get("message", {}).get("ts")
        try:
            actions.authorized(user)
            if body.get("team", {}).get("id") != identity["team_id"]:
                raise BotError("wrong_workspace")
            item = body["actions"][0]
            if item["action_id"] == "take_over":
                ident = actions.take_over(user, item["value"], channel, ts)
                ack()
                executor.submit(safe, worker.notify, ident)
                return
            if item["action_id"] == "cancel":
                ident = actions.cancel(user, item["value"], channel, ts)
                ack()
                executor.submit(safe, worker.notify, ident)
                return
            if item["action_id"] == "assist":
                inquiry = actions.resolve_assistance(user, item["value"], channel, ts)
            else:
                inquiry, _ = actions.resolve(user, item["value"], channel, ts)
            if item["action_id"] == "reject":
                ident = actions.reject(user, item["value"], channel, ts)
                ack()
                executor.submit(safe, worker.notify, ident)
                return
            if item["action_id"] == "regenerate":
                ack()
                executor.submit(safe, worker.notify, inquiry["id"])
                executor.submit(
                    safe,
                    gateway.warn,
                    channel,
                    user,
                    "다시 생성 기능은 제거되었습니다. 최신 카드의 ‘직접 수정’을 이용해 주세요.",
                )
                return
        except (BotError, KeyError, IndexError, TypeError):
            ack()
            executor.submit(
                safe,
                gateway.warn,
                channel,
                user,
                "현재 승인자와 최신 카드에서만 처리할 수 있습니다.",
            )
            return
        ack()

        def act(fn, *args):
            try:
                fn(*args)
            except BotError as exc:
                gateway.warn(
                    channel,
                    user,
                    f"처리하지 못했습니다 ({exc.code}). 최신 카드와 연결 상태를 확인해 주세요.",
                )
            except Exception:
                store.audit(None, "system", "interaction_failed")
                gateway.warn(
                    channel, user, "처리 결과를 확인하지 못했습니다. 상태를 확인해 주세요."
                )

        if item["action_id"] == "post":
            executor.submit(act, actions.post, user, item["value"], channel, ts)
        else:
            executor.submit(
                act,
                actions.open_modal,
                user,
                item["value"],
                channel,
                ts,
                body["trigger_id"],
                item["action_id"],
            )

    for action in (
        "post",
        "edit",
        "regenerate",
        "lookup",
        "reject",
        "cancel",
        "assist",
        "take_over",
    ):
        app.action(action)(button)

    def submitted(ack, body):
        try:
            user = body.get("user", {}).get("id")
            actions.authorized(user)
            if body.get("team", {}).get("id") != identity["team_id"]:
                raise BotError("wrong_workspace")
            view = body["view"]
            values = view["state"]["values"]
            content = values.get("content", {}).get("value", {}).get("value") or ""
            observed = values.get("observed_at", {}).get("value", {}).get("value")
            ident = actions.submit(
                user,
                view["private_metadata"],
                view["callback_id"].removeprefix("dougle_"),
                content,
                observed,
            )
        except (BotError, KeyError, TypeError) as exc:
            message = (
                "다시 생성 기능은 제거되었습니다. 이 창을 닫고 최신 카드의 ‘직접 수정’을 이용해 주세요."
                if isinstance(exc, BotError) and exc.code == "action_unavailable"
                else "최신 카드와 입력 내용을 확인해 주세요."
            )
            ack(
                response_action="errors",
                errors={"content": message},
            )
            return
        ack()
        executor.submit(safe, worker.show_card, ident)

    for action in ("edit", "regenerate", "lookup", "reject", "assist"):
        app.view("dougle_" + action)(submitted)
    return app


def serve(config, secrets, *, allow_unverified_readers=False):
    config.validate()
    if not apple_silicon():
        raise BotError("apple_silicon_required")
    from slack_bolt.adapter.socket_mode.builtin import SocketModeHandler

    with InstanceLock(config.home / "runtime.lock"):
        store = Store(config.home / "bot.db")
        stop = threading.Event()
        handler = executor = None
        threads = []
        stage = "slack_check"

        def halt(*args):
            stop.set()
            store.stop()

        signal.signal(signal.SIGTERM, halt)
        signal.signal(signal.SIGINT, halt)
        try:
            store.begin_startup(os.getpid())
            report(store, "slack_checking")

            def cancelled():
                return stop.is_set() or store.control()["desired"] != "running"

            bot, app_token = secrets.get("bot"), secrets.get("app")
            if not bot or not app_token or not config.slack.allowed_channel_ids:
                raise BotError("slack_check")
            gateway = BoltSlackGateway(bot)
            gateway.cancelled = cancelled
            identity = gateway.identity()
            if config.slack.workspace_id and config.slack.workspace_id != identity["team_id"]:
                raise BotError("wrong_workspace")
            for channel in config.slack.allowed_channel_ids:
                gateway.call("conversations_history", channel=channel, limit=1)
            if cancelled():
                raise BotError("bot_stopped")
            store.begin_run(
                os.getpid(), identity["team_id"], identity["user_id"], require_starting=True
            )
            from . import __version__

            store.audit(None, "system", "runtime_started", __version__)

            stage = "engine_check"
            checked = check_engine(
                config.engine,
                store,
                ClaudeCliEngine(
                    config.engine, config.home, cancelled=cancelled, startup_probe=True
                ),
                allow_unverified_readers=allow_unverified_readers,
            )
            if cancelled():
                raise BotError("bot_stopped")
            stage = "slack_check"
            engine = ClaudeCliEngine(config.engine, config.home, cancelled=cancelled)
            # Engine.run owns invocation-local state. Do not serialize engine calls.
            # Sharing Worker also shares cards_lock and Monitor's rotation lock.
            worker = Worker(store, config, engine, gateway)
            actions = Actions(store, config, gateway, worker)
            executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="dougle-interactions")
            app = build_app(gateway, bot, identity, store, config, worker, actions, executor)
            handler = SocketModeHandler(app, app_token=app_token)
            store.recover()
            store.configure_processing(config.engine.max_parallel)
            # Questions sent while startup checks were running count as stopped time.
            store.begin_run(
                os.getpid(), identity["team_id"], identity["user_id"], require_starting=True
            )
            store.audit(None, "system", "runtime_started", __version__)
            handler.connect()
            # Socket Mode can connect asynchronously. Never report ready merely on connect().
            for _ in range(100):
                if cancelled():
                    raise BotError("bot_stopped")
                if handler.client.is_connected():
                    break
                stop.wait(0.1)
            else:
                raise BotError("slack_check")
            report(
                store,
                "connected",
                connections=checked["connections"],
                continued=checked["continued_without_verification"],
            )
            store.heartbeat(True)
            stage = "runtime_connection_failed"
            worker.notify_recovered()

            def memory_work():
                # Proposals drain independently of inquiry delivery. The consumer
                # must honor stop without waiting for the pending queue to empty.
                try:
                    from .memory_worker import run_memory_worker

                    run_memory_worker(store, config.home, stop)
                except Exception:
                    store.audit(None, "system", "memory_worker_failed")

            memory_thread = threading.Thread(target=memory_work, name="dougle-memory", daemon=True)
            memory_thread.start()
            threads.append(memory_thread)
            for index in range(config.engine.max_parallel):
                thread = threading.Thread(
                    target=process_inquiries,
                    args=(worker, store, stop),
                    name=f"dougle-inquiry-{index + 1}",
                    daemon=True,
                )
                thread.start()
                threads.append(thread)
            while not stop.wait(0.5):
                if store.control()["desired"] != "running":
                    break
                store.heartbeat(handler.client.is_connected())
        except Exception as exc:
            code = exc.code if isinstance(exc, BotError) else stage
            if code not in (
                "required_skills",
                "optional_connections",
                "daily_budget_exceeded",
                "engine_check",
                "bot_stopped",
            ):
                code = stage
            if code in ("slack_check", "bot_stopped"):
                report(store, code)
            store.stop(code)
            raise BotError(code) from None
        finally:
            stop.set()
            store.stop()
            try:
                if handler:
                    handler.close()
            finally:
                for thread in threads:
                    thread.join()
                if executor:
                    executor.shutdown(wait=True, cancel_futures=True)
                store.close()
